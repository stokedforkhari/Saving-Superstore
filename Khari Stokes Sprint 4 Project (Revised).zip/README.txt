Hello, I have attached a link to my Sprint 4 Project below

https://public.tableau.com/views/KhariStokesSprint4ProjectDashboard/ProfitsBasedonSub-CategoriesRegions?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link